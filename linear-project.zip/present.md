**First Group**
by. OTcool & ผมมีเบนซ์สี่คัน
topic : วิเคราะห์คาดการณ์ความสัมพันธ์ผู้ติดเชื้อโควิด 19่่
_purpose_ :  
_resource_ : กรมควบคุมโรค กระทรวงสาธารณะสุข, department of disease
target group : ผู้ที่สนใจข้อมูลเกียวกับโควิด แนวโน้มผู้ติดเชื้อ จน.ผู้ฉีดวัคซีน
data set : infected no., cured no., vaccined (1, 2, 3 doses)
math related : linear regression, Coefficient of Determination (R square)

**Car Price Prediction**
goal : นำข้อมูลต่างๆ มาวิเคราะห์ เพื่อคาดเดาราคาของรถยนต์ในอนาคตได้
data : name, year, seeling price, km driven, fuel, seller type, tranmission(auto, mannual), owner(1st hand or 2nd hand)
math related : linear regression, matrix

**Diamond Price**
goal :
target group : the interested, the appraiser,
data : weight, depth, lenght, width, color, quality, Clarity, Price
math related : linear regression,
resource : Diamonds from Kaggle (50k sets)

**ความสัมพันธ์ระหว่างข้อมูลผู้เดินทางภายในประเทศ กับยอดผู้ติดเชื้อโควิด**
goal : หาความสัมพันธ์ระหว่างข้อมูลผู้เดินทางภายในประเทศ กับยอดผู้ติดเชื้อโควิด
target group : หน่วยงานต่างๆที่เกี่ยวข้องทางด้านการขนส่งสาธารณะ
data : 1. ข้อมูลการเดินทางของประชาชนในระหว่างการระบาด covid-19  
2. ข้อมูลยอดผู้ติดเชื้อ covid-19 รายวัน (1 มกราคม 63 - 30 สิงหาคม 64)
math related : Linear regression หาแนวโน้มของข้อมูล 2 ชุด, Matrix Covariance หาความสัมพันธ์ระหว่างข้อมูลผู้ติดเชื้อรายวัน 2 ชุด
resource : สคบ. and กระทรวงคมนาคม

---

goal :
target group : จะได้รู้ความเสี่ยงของช่วงอายุกับโอกาสในการติดโควิด
data : ประชากรในประเทศไทย
math related :
resource :

**สำรวจความนิยม วิเคราะห์แนะนำแนวเกมต่างๆ**
target : สามารถแนะนำแนวเเกมที่เหมาะสม
target group : คนที่ชอบเล่นเกม
data : เอกลักษณ์ของแนวเกม(ประเภทของเกม)
math related : vector similarity แบ่งแยกประเภทของเกมต่างๆ, Matrix เก็บข้อมูล
resource :
